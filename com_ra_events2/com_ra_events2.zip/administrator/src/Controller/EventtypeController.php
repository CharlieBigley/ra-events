<?php
/**
 * @version    3.2.0
 * @package    com_ra_events
 * @author     Charlie Bigley <charlie@bigley.me.uk>
 * @copyright  2025 Charlie Bigley
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Ramblers\Component\Ra_events\Administrator\Controller;

\defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\FormController;

/**
 * Eventtype controller class.
 *
 * @since  2.0
 */
class EventtypeController extends FormController
{
	protected $view_list = 'eventtypes';
}
